package neuronio;


public class neuronio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**
	*erro=resultadoEsperado-resultoReal
	*formula: p=p+erro*taxaDeAprendizado*entrada
	* entra: 2 peso, 1 entrada,
	* saida: 1 numero
	* **/
		
		float entrada=1;
		
		float peso1=(float) 0;
		float peso2=(float) 0.8;
		
		float erro=(float)1.2;
		float taxaDeAprendizado=(float) 0.05;
		
		float resultadoEsperado=entrada+entrada;
		float resultado;
		/**
		
		erro=resultadoEsperado-peso1-peso2;
		peso1=peso1+erro*taxaDeAprendizado*entrada;
		peso2+=erro*taxaDeAprendizado*entrada;
		
		System.out.println("peso1= "+peso1);
		System.out.println("peso2= "+peso2);
		erro=resultadoEsperado-peso1-peso2;
		
		
		System.out.println("erro= "+erro);
		
		**/
		
		
		for(int i=1;i<6;i++) {
			
			entrada=i;
			resultadoEsperado=entrada+entrada;		
			erro=resultadoEsperado-(peso1+peso2)*entrada;
			System.out.println("erro= "+erro);
			peso1=peso1+erro*taxaDeAprendizado*entrada;
			peso2+=erro*taxaDeAprendizado*entrada;
			
			System.out.println("peso1= "+peso1);
			System.out.println("peso2= "+peso2);
			erro=resultadoEsperado-peso1-peso2;		
			
			
		}
		

		//teste
		
for(int i=1;i<11;i++) {
			
			entrada=i;
			resultado=entrada*peso1+entrada*peso2;
			System.out.println(entrada+" + "+entrada+" = "+resultado);
			
			
			
		}
		
		
	}

}